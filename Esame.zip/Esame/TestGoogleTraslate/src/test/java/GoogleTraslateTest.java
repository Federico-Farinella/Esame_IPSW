
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class GoogleTraslateTest {
    @Test
    public void TestGoogleTraslate() throws Exception {
        GoogleTraduction traduct = new GoogleTraduction();
        int num = traduct.numOfWords();
        assertTrue(num < 10);
    }
}
