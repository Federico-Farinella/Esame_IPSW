import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.lang.Thread;
import java.util.List;

public class GoogleTraduction {
    public int numOfWords() throws Exception {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\casastudio.000\\IdeaProjects\\TestGoogleTraslate\\src\\test\\java\\Driver\\chromedriver2.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://translate.google.it/?hl=it");
        Thread.sleep(2000);

        driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div/div/div[2]/div[1]/div[4]/div[1]/div[1]/form[2]/div/div/button/span")).click();

        driver.findElement(By.xpath("//*[@id=\"i12\"]/span[3]")).click();
        driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/c-wiz/div[2]/c-wiz/div/div[2]/div[3]/c-wiz[1]/span/span/div/textarea")).sendKeys("la pizza margherita è senza ananas");

        // Do tempo al traduttore di riportare la stringa tradotta nella TextBox altrimenti mi da errore!!!
        Thread.sleep(4000);

        String trad = driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/c-wiz/div[2]/c-wiz/div/div[2]/div[3]/c-wiz[2]/div/div[8]")).getText();

        driver.close();
        // Devo togliere dalla stringa ottenuta la sottostringa "Controlla i dettagli" che Google Traductor ha nella TextBox della traduzione.
        String traduction = trad.replace("Controlla i dettagli", "");
        List<String> parole = new java.util.ArrayList<>(List.of(traduction.split("\\s")));

        return parole.size();

    }
}
